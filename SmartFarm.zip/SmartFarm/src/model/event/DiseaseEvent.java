package model.event;

import farm.FarmManager;
import model.livestock.Livestock;

public class DiseaseEvent extends GameEvent {
    private static final int SICK_LIMIT = 3;

    public DiseaseEvent() {
        super("牲畜疫病", "疫病传播！牲畜容易反复生病，生病" + SICK_LIMIT + "次会死亡！");
    }

    @Override
    public void apply(FarmManager farm) {
        int count = 0;
        for (Livestock animal : farm.getLivestockList()) {
            if (Math.random() < 0.5) {
                animal.setSick(true);
                animal.incTimesSick();
                count++;
                if (animal.getTimesSick() >= SICK_LIMIT) {
                    animal.setDead(true);
                    farm.addMessage("  [死亡] " + animal.getName() + "因反复生病" + SICK_LIMIT + "次而死亡！");
                }
            }
        }
        if (count > 0) {
            farm.addMessage("  [疫病] " + count + "头牲畜生病了（已生病次数累计，满" + SICK_LIMIT + "次死亡），请注意治疗。");
        }
    }
}
