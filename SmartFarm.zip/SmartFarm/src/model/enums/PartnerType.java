package model.enums;

public enum PartnerType {
    GENTLE_TEACHER("温柔教师", "精打细算", "集市买入价格打9折"),
    AGRICULTURE_EXPERT("农业专家", "科学种植", "土地肥力消耗降低20%，作物抗灾+10%"),
    BUSINESS_ELITE("商业精英", "风险投资", "每周获得下周市场价格预测报告"),
    CHEF("厨师能手", "农产品深加工", "初级作物可加工成高价值产品");

    private final String name;
    private final String skill;
    private final String description;

    PartnerType(String name, String skill, String description) {
        this.name = name;
        this.skill = skill;
        this.description = description;
    }

    public String getName() { return name; }
    public String getSkill() { return skill; }
    public String getDescription() { return description; }
}
